#include "ShockWaveSolver.h"
#include <fstream>
#include <iostream>
#include "Randomizer.h"
#include "string"

using namespace std;

ShockWaveSolver::ShockWaveSolver(double t, int k, int M, int histSect, double histMin, double histMax, double visuaDt) :tmax(t),
	k(k), M(M), initHistoX(histSect, histMin, histMax),lastHistoX(histSect, histMin, histMax),
	initHistoV(histSect, histMin, histMax), lastHistoV(histSect, histMin, histMax), visuaDt(visuaDt)
{
	double dt = t / k;
	int N = 200;
	for (int i = 0; i < cellsBounds.size() - 1; ++i)
	{
		const double left = cellsBounds[i];
		const double right = cellsBounds[i + 1];
		const double Kn = 1;
		cells.emplace_back(SpatHomSolver(N, dt, Kn, left, right));
	}
	Randomizer::InitOmegas(20, 20);

	int visuaTimeSteps = int(t / visuaDt);
	rhoX.assign(visuaTimeSteps, Histogram(histSect, histMin, histMax));
}

void ShockWaveSolver::CheckParams()
{
	constexpr double gamma = 1.6;
	constexpr double gam_inv = 1.0 / (gamma - 1);
	const double r0 = params.rho2;
	const double r1 = params.rho1;
	const double u = params.u1;
	const double D = r1 * u / (r1 - r0);
	const double E1 = -r0 * D * (D * u * gam_inv + 0.5 * u * u) / (r0 * D - r1 * D - (gamma - 1) * r1 * u);
	const double E0 = r1 / r0 * E1 - D * u * gam_inv;
	params.D = D;
	params.E1 = E1;
	params.E2 = E0;
}

void ShockWaveSolver::InitialDistribution()
{
	for (int i = 0; i < cells.size() / 2; ++i)
	{
		double m1 = (cells[i].right - cells[i].left) * params.rho1 / cells[i].initN;
		cells[i].InitialDistribution(m1, params.u1, params.E1);
	}
	for (int i = cells.size() / 2; i < cells.size(); ++i)
	{
		double m2 = (cells[i].right - cells[i].left) * params.rho2 / cells[i].initN;
		cells[i].InitialDistribution(m2, params.u2, params.E2);
	}
}

void ShockWaveSolver::Solve()
{
	for (int m = 1; m <= M; ++m)
	{
		InitialDistribution();
		initHistoX.ReplenishX(cells);
		int curVisua = 0;
		double t = 0;
		for (int timeStep = 1; timeStep <= k; ++timeStep)
		{
			for (auto& cell : cells)
			{
				DataInfo info = cell.CalculateStep();
			}
			UpdateCells();
			t = timeStep * (tmax / k);
			if (t > (curVisua + 1) * visuaDt)
			{
				rhoX[curVisua].ReplenishX(cells);
				++curVisua;
			}
		}
		//lastHistoX.ReplenishX(cells);
		std::cout << m << "\n";
	}
	initHistoX.Normalize();
	ofstream file("init.txt");
	initHistoX.Write(file);
	file.close();
	for (int i = 0; i < rhoX.size(); ++i)
	{
		rhoX[i].Normalize();
		ofstream file("rhoX_" + to_string((i + 1) * visuaDt) + ".txt");
		rhoX[i].Write(file);
		file.close();
	}
}

void ShockWaveSolver::UpdateCells()
{
	for (auto& cell : cells)
	{
		for (auto& particle : cell.layer)
		{
			particle.x += (particle.v.x - params.D) * cell.dt;
		}
	}
	ReturnInDomain();
	vector<Particle> movingParticles;
	for (auto& cell : cells)
	{
		auto forMoves = cell.PrepareToChangeCell();
		movingParticles.insert(movingParticles.end(), forMoves, cell.layer.end());
		cell.layer.erase(forMoves, cell.layer.end());
	}
	for (auto& particle : movingParticles)
	{
		double x = particle.x;
		if (x < cellsBounds[0])
		{
			cells[0].layer.push_back(particle);
		}
		else if (x > cellsBounds.back())
		{
			cells.back().layer.push_back(particle);
		}
		else
		{
			auto comp = [=](SpatHomSolver& cell) {return x > cell.left && x <= cell.right; };
			std::find_if(cells.begin(), cells.end(), comp)->layer.push_back(particle);
		}
	}
}
void ShockWaveSolver::ReturnInDomain()
{
	for (auto& cell : cells)
	{
		for (auto& particle : cell.layer)
		{
			if (particle.x < cellsBounds.front())
			{
				//particle.x += abs(particle.x - cellsBounds.front()) * 2;
				//particle.v = particle.v * (-1.0);
				cells.front().PlayParticle(particle, params.u1, params.E1);
			}
			if (particle.x > cellsBounds.back())
			{
				//particle.x -= abs(particle.x - cellsBounds.back()) * 2;
				//particle.v = particle.v * (-1.0);
				cells.back().PlayParticle(particle, params.u2, params.E2);

			}
		}
	}
	//cells.front().DistribUniformly();
	//cells.back().DistribUniformly();
}
double ShockWaveSolver::CalcD()
{
	const double gamma = 1.6;
	const double p1 = (gamma - 1) * params.rho1 * params.E1;
	const double p2 = (gamma - 1) * params.rho2 * params.E2;
	return params.u1 * sqrt((p2 - p1) / (params.u1 - params.u2));
}
