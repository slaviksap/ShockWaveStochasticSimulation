#include "SpatHomSolver.h"
#include "Randomizer.h"
#include <algorithm>
#include <iostream>
#include "Histogram.h"
using namespace std;

SpatHomSolver::SpatHomSolver(int N, double dt, double Kn, double left, double right)
	: N(N), dt(dt), Kn(Kn), prev_layer(N), layer(N), n(1.0), left(left), right(right), initN(N)
{
	sdt = sqrt(dt);
	dw = 3.14159265358979 / 4.0;
}
void SpatHomSolver::InitialDistribution(double m, double u, double E)
{
	N = initN;
	layer.assign(initN, Particle());
	normal_distribution<> normx(u, sqrt(E));
	normal_distribution<> norm(0, sqrt(E));
	uniform_real_distribution<> uni(left, right);
	for (auto& particle : layer)
	{
		particle.v.x = normx(Randomizer::gen());
		particle.v.y = norm(Randomizer::gen());
		particle.v.z = norm(Randomizer::gen());

		//particle.x = uni(Randomizer::gen());

		particle.mass = m;
	}
	DistribUniformly();
}
void SpatHomSolver::DistribUniformly()
{
	double dx = (right - left) / layer.size();
	double cur_x = left + dx / 2;
	for (auto& particle : layer)
	{
		particle.x = cur_x;
		cur_x += dx;
	}
}
double Energy(vector<Particle>& v)
{
	double E = 0;
	for (const auto& particle : v)
	{
		const double U = magnitide(particle.v);
		E += 0.5 * U * U;
	}
	return E;
}

DataInfo SpatHomSolver::CalculateStep()
{
	prev_layer = layer;
	N = layer.size();
	double mass = 0;
	for (auto& particle : prev_layer)
		mass += particle.mass;
	n = mass / (right - left);
	DataInfo info;
	double StartEnergy = Energy(layer);
	Histogram3D F(5, -5.0, 5.0, 1);
	F.Build(layer);
	for (int i = 0; i < N; ++i)
	{
		for (int j = i + 1; j < N; ++j)
		{
			auto w = Randomizer::sampleOmega();
			double prod = dot(w, layer[i].v - layer[j].v);
			double l = abs(prod) * dt;
			double lambda = l / N / Kn / 2 * dw * n * F.Get(layer[j].v);

			if (Randomizer::sampleUni() < lambda)
			{
				Vec3 dv = w * prod;
				layer[i].v = layer[i].v - dv;
				layer[j].v = layer[j].v + dv;
				++info.colCount;
			}
		}

	}
	info.Echange = abs(StartEnergy - Energy(layer));
	return info;
}

vector<Particle>::iterator SpatHomSolver::PrepareToChangeCell()
{
	auto end_iter = layer.end();
	for (auto iter = layer.begin(); iter != end_iter;)
	{
		if (iter->x >= left && iter->x < right)
		{
			++iter;
		}
		else
		{
			--end_iter;
			swap(*iter, *end_iter);
		}
	}
	return end_iter;
}
void SpatHomSolver::PlayParticle(Particle& p, double u, double E)
{
	normal_distribution<> norm(0, sqrt(E));
	uniform_real_distribution<> uni(left, right);
	p.v.x = norm(Randomizer::gen()) + u;
	p.v.y = norm(Randomizer::gen());
	p.v.z = norm(Randomizer::gen());

	p.x = uni(Randomizer::gen());
}

